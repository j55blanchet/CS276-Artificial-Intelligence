# PA4 | Constraint Satisfaction | COSC 276-AI
Julien Blanchet | Prof. Li | Fall 2020

---

## Setup

This program is built for (and relies on) **python 3.8+**.

## Running

* Option 1: Use pytest
    * `pip install pytest`
    * `pytest` (in this folder)
* Option 2: Execute main methods
    1. Add tests calls you want to execute to the `__name__ == "__main__"` boiler plate
    2. Execute `python test_circuit_layout.py` and / or `test_map_coloring.py`
